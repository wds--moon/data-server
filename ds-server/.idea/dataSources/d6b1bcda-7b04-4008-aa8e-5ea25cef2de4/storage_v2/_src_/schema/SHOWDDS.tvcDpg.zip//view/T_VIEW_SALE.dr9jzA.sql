create view T_VIEW_SALE as
select 
va.log_id,
info.user_name,
ca.sale_price,ca.count,ca.status pro_status,
ca.product_id,ca.order_id,va.VALID_NUM,va.GMT_UPDATE,va.VALID_STATUS
from ORDER_PRODUCT_CAPTCHA ca 
LEFT JOIN ORDER_INFO info on info.id = ca.order_id
,T_VIEW_VALID va where  va.order_id = ca.order_id and va.product_id = ca.product_id
/


create PROCEDURE           "DDS_COMMON_GET_CUSTOMER_USE" AS
begin
  --select LAST_ORDERUSE_DATE into lastDate from DISTRIBUTOR where D_ID=to_number(IN_DISTRIBUTOR_ID);
 -- intNowDate :=oracle_to_unix(nowDate);
  nowDateStr :=to_char(sysdate,'yyyy-mm-dd HH24:MI:SS');
  nowDate :=to_date(nowDateStr,'yyyy-mm-dd HH24:MI:SS');
  --lastDateStr?????????????????????????
  if(lastDateStr is null or lastDateStr='') then 
    open resultList for 
    select u.ORDER_NO,max(u.ORDER_COUNT) as ORDER_COUNT,sum(u.USE_COUNT) as useCount,max(u.D_DETAIL_ID) as D_DETAIL_ID,max(u.ENTRY_TIME) as ENTRY_TIME
     from all_order_use u inner join all_orders o on u.ORDER_ID=o.ORDER_ID where o.D_ID=to_number(IN_DISTRIBUTOR_ID) and  u.ENTRY_TIME<=nowDate
     group by u.ORDER_NO;
  
  else
    
  lastDate :=to_date(lastDateStr,'yyyy-mm-dd HH24:MI:SS');
 --lastDateStr :=to_char(lastDate,'yyyy-mm-dd HH24:MI:SS');
 -- update DISTRIBUTOR set LAST_ORDERUSE_DATE=nowDate where D_ID=to_number(IN_DISTRIBUTOR_ID);
 -- select count(*) into useCount from PRO_ORDER_DETAIL where D_ID=to_number(IN_DISTRIBUTOR_ID) and ENTRY_TIME>intLastDate and ENTRY_TIME<=intNowDate;
  open resultList for 
     
    select u.ORDER_NO,max(u.ORDER_COUNT) as ORDER_COUNT,sum(u.USE_COUNT) as useCount,max(u.D_DETAIL_ID) as D_DETAIL_ID,max(u.ENTRY_TIME) as ENTRY_TIME 
     from all_order_use u inner join all_orders o on u.ORDER_ID=o.ORDER_ID where o.D_ID=to_number(IN_DISTRIBUTOR_ID) and  u.ENTRY_TIME<=nowDate
     and u.ENTRY_TIME>lastDate
     group by u.ORDER_NO;
      --AND ROWNUM <= to_number(CURRENT_PAGE)*to_number(PAGE_SIZE)) ab where ab.rowno>(to_number(CURRENT_PAGE)-1)*to_number(PAGE_SIZE);
 end if;
  /


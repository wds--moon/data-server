create view T_VIEW_VALID as
select id log_id, VALID_NUM,PRODUCT_ID,order_id,to_char(GMT_UPDATE,'YYYYmmdd') GMT_UPDATE ,STATUS VALID_STATUS  from CAPTCHA_LOG
/


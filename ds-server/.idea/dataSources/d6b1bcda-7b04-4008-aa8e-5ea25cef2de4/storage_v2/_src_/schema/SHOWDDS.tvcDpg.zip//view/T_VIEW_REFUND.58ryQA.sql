create view T_VIEW_REFUND as
select o.user_name,r.order_id,to_char(r.create_time,'YYYYmmdd') create_time,create_time time,"SUM"(p.refund_count) refund_count 
from ORDER_REFUND r,ORDER_REFUND_PRODUCT p ,ORDER_INFO o
where r.id = p.refund_id and r.ORDER_ID = p.order_id and o.id = r.order_id group by o.user_name, r.order_id,create_time
/


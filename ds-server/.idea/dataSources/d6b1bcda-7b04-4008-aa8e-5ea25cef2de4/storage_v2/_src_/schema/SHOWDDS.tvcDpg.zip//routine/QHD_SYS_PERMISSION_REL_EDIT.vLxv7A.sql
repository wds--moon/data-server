create PROCEDURE           "QHD_SYS_PERMISSION_REL_EDIT" AS
begin
  

--??????
open down_level;
 loop
   fetch down_level into permissionId ;
   exit when down_level%notfound ; 
   
   
   delete from SYS_ROLE_PERMISSION_REL where ROLE_ID = P_ROLE_ID and PUR_ID = permissionId;
   
   if do_type = 'checked' then
     --????
     select sys_guid() into uuid from dual; 
     insert into SYS_ROLE_PERMISSION_REL(rel_id,Role_Id,PUR_ID)values(uuid,P_ROLE_ID,permissionId);
   end if;
   
 end loop;
/

